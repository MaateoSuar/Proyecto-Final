import FormularioRegistro from '../componentes/FormularioRegistro';

export default function PaginaRegistro() {
  return <FormularioRegistro />;
}
