import Reservar from '../componentes/Reservar';

export default function PaginaPerfilProveedor() {
  return <Reservar />;
}