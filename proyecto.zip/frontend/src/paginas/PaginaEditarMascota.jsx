import React from 'react';
import EditarMascota from '../componentes/EditarMascota';
import '../estilos/perfilmascotas.css';

export default function PaginaEditarMascota() {
  return <EditarMascota />;
} 