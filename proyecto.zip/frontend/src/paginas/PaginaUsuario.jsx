import UsuarioEdit from '../componentes/UsuarioEdit';

export default function PaginaUsuario() {
  return <UsuarioEdit />;
}
