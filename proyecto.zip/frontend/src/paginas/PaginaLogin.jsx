import FormularioLogin from '../componentes/FormularioLogin';

export default function PaginaLogin() {
  return <FormularioLogin />;
}