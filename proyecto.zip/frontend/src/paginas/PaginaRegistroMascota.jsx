import PerfilMascotas from "../componentes/PerfilMascotas";
import '../estilos/perfilmascotas.css';
export default function PaginaRegistroMascotas() {
    return <PerfilMascotas/>
}